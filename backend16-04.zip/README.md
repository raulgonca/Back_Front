<p align="center" style="padding-top: 3em">
  <a target="blank"><img src="https://beebit.es/wp-content/uploads/2017/07/marca-sin-bordes.png" width="200" alt="Nest Logo" /></a>
</p>

<h1 align="center">
Basic NestJs Application
</h1>

## Init
### Run the containers:
```bash
docker compose up --build
```

### Install application dependencies:
```bash
cd ./api && npm install
```

<br></br>
App will run at: [http://localhost:3000](http://localhost:3000)
