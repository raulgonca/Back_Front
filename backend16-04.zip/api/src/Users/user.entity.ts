import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { ApiProperty, ApiTags } from '@nestjs/swagger';
import { Project } from '../Projects/project.entity';

@ApiTags('Users') // Etiqueta para agrupar en la documentación de Swagger
@Entity()
export class User {
    @ApiProperty({ description: 'ID del usuario' })
    @PrimaryGeneratedColumn()
    id: number;

    @ApiProperty({ description: 'Nombre de usuario' })
    @Column()
    username: string;

    @ApiProperty({ description: 'Contraseña del usuario' })
    @Column('jsonb', { nullable: true })
    password: string;
  
    @OneToMany(() => Project, project => project.User)
    projects: Project[];
}
