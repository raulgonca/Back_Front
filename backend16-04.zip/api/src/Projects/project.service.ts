import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Project } from './project.entity';

@Injectable()
export class ProjectService {
  constructor(
    @InjectRepository(Project)
    private readonly projectRepository: Repository<Project>,
  ) {}

  async createProject(CreateProjectDto): Promise<Project> {
    const project = this.projectRepository.create(CreateProjectDto)
    return this.projectRepository.save(CreateProjectDto);
  }

  async getAllProject(): Promise<Project[]> {
    return this.projectRepository.find();
  }

  async deleteProject(id: number): Promise<void> {
    await this.projectRepository.delete(id);
  }

  async findOne(id: number): Promise<Project | undefined> {
    return this.projectRepository.findOne({ where: { id } });
  }
  

  async updateProject(
    id: number,
    nameproject: string,
    description: string,
    fechaInicio: Date,
    fechaFinalizacion: Date,
  ): Promise<Project> {
    const project = await this.projectRepository.findOne({ where: { id } });

    if (!project) {
      throw new Error(`Project with id ${id} not found`);
    }

    // Aquí puedes realizar cualquier lógica adicional que necesites para la actualización del proyecto
    project.nameproject = nameproject;
    project.description = description;
    project.fechaInicio = fechaInicio;
    project.fechaFinalizacion = fechaFinalizacion;

    return this.projectRepository.save(project);
  }
}
